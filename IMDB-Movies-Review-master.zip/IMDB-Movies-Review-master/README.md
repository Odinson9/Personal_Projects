# IMDB-Movies-Review
This model uses the imdb dataset to predict the best movies in particular area.
