# Home-loan
This is the machine learning applied on the home loan data. This model predicites who can pay the loan back and the prediction is very efficient.
All the information predicted by this model is accurate.
The dataset was obtained from here: : https://datahack.analyticsvidhya.com/contest/practice-problem-loan-prediction-iii/
