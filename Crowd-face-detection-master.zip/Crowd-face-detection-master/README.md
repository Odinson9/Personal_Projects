# Crowd-face-detection

In this project we have detected number of people present in crowd by detecting there faces. We have done this by using OpenCV library and the then we have used its function so that we can get the accuracy. In this we have used haarcascade file of fontalface detection.
